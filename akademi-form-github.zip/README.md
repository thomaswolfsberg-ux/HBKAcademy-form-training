# Akademi Træningsregistrering (klar til GitHub + Render)

Dette projekt er klar til at blive lagt på GitHub og hostet på Render (gratis).
- Mobilvenlig forside (checkbox-lister, store klikfelter)
- Separate CSV-eksporter pr. hold, long-format (ingen tomme felter)
- Spillere/hold hentes fra `data/*.csv`
- Kun nabo-hold kan vælges som gæster

## Mapper
- `public/index.html` — selve formularen (mobilvenlig)
- `server.js` — Node/Express-server
- `data/teams.csv` — rækkefølgen afgør nabo-hold (nabo = forrige/næste)
- `data/players.csv` — spillere (sæt `active=false` for at skjule en spiller)
- `exports/` — CSV-uddata (oprettes og skrives automatisk)

## Lokalt (valgfrit)
1) Installer Node.js (LTS) fra https://nodejs.org
2) I projektmappen:
   npm install
   npm start
3) Åbn http://localhost:3000

## GitHub → Render (hosting)
1) Opret et nyt repository på GitHub
2) Upload alle filer og mapper fra denne pakke (bevar mappe-strukturen)
3) På https://render.com: New → Web Service → Connect your GitHub → vælg repo
4) Start command:  node server.js
5) Region: Frankfurt (EU Central)
6) Deploy — du får en offentlig URL (del den med trænere)

## Opdater spillere/hold
- Ret i `data/players.csv` / `data/teams.csv`
- Besøg `/api/reload` på jeres URL (fx https://ditnavn.onrender.com/api/reload)

