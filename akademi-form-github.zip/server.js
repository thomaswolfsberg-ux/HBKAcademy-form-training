import express from "express";
import cors from "cors";
import fs from "fs";
import path from "path";
import os from "os";
import slugify from "slugify";
import { parse } from "csv-parse/sync";

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

const DATA_DIR = path.join(process.cwd(), "data");
const TEAMS_CSV = path.join(DATA_DIR, "teams.csv");
const PLAYERS_CSV = path.join(DATA_DIR, "players.csv");
const EXPORT_DIR = path.join(process.cwd(), "exports");
if (!fs.existsSync(EXPORT_DIR)) fs.mkdirSync(EXPORT_DIR);

let TEAMS = [];
let TEAM_NAMES = {};
let NEIGHBORS = {};
let ROSTER = {};
let ALL_PLAYERS = [];
let BY_ID = {};

const ABSENCE_REASONS = ["sygdom","skade","skole","ferie","andet"];
const pid = (team, number, name) =>
  `${team}_${number}_${slugify(String(name), { lower: true, strict: true })}`;

function teamCsvPath(team) { return path.join(EXPORT_DIR, `${team}.csv`); }

function ensureHeaderIfNeeded(team, headerColumns) {
  const p = teamCsvPath(team);
  if (!fs.existsSync(p) || fs.statSync(p).size === 0) {
    const base = "timestamp,assigned_team,record_type,date,submitted_by";
    const header = `${base}${headerColumns.length ? ","+headerColumns.join(",") : ""}\n`;
    fs.appendFileSync(p, header);
  }
}

function appendRow(team, baseCols, extraCols) {
  const p = teamCsvPath(team);
  const line = [...baseCols, ...extraCols].map(v => {
    if (v == null) return "";
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g,'""')}"` : s;
  }).join(",") + "\n";
  fs.appendFileSync(p, line);
}

function computeNeighbors(list) {
  const map = {};
  list.forEach((t, i) => {
    const arr = [];
    if (i-1 >= 0) arr.push(list[i-1]);
    if (i+1 < list.length) arr.push(list[i+1]);
    map[t] = arr;
  });
  return map;
}

function loadCsvData() {
  const rawTeams = fs.readFileSync(TEAMS_CSV, "utf8");
  const teamsRows = parse(rawTeams, { columns: true, skip_empty_lines: true, trim: true });
  TEAMS = teamsRows.map(r => r.team_id);
  TEAM_NAMES = Object.fromEntries(teamsRows.map(r => [r.team_id, r.team_name || r.team_id]));
  NEIGHBORS = computeNeighbors(TEAMS);

  const rawPlayers = fs.readFileSync(PLAYERS_CSV, "utf8");
  const playerRows = parse(rawPlayers, { columns: true, skip_empty_lines: true, trim: true });

  ROSTER = {};
  TEAMS.forEach(t => ROSTER[t] = []);

  playerRows.forEach(r => {
    const team = r.team_id;
    if (!TEAMS.includes(team)) return;
    const number = Number(r.number);
    const name = r.name;
    const active = String(r.active || "true").toLowerCase() === "true";
    const player_id = pid(team, number, name);
    const entry = { team, number, name, active, player_id };
    ROSTER[team].push(entry);
  });

  for (const t of TEAMS) {
    ROSTER[t].sort((a,b) => (a.number - b.number) || a.name.localeCompare(b.name, "da"));
  }

  ALL_PLAYERS = TEAMS.flatMap(t => ROSTER[t]);
  BY_ID = Object.fromEntries(ALL_PLAYERS.map(p => [p.player_id, p]));
}

loadCsvData();

app.get("/api/teams", (req, res) => {
  res.json(TEAMS.map(t => ({ id: t, name: TEAM_NAMES[t] })));
});

app.get("/api/teams/:teamId/players", (req, res) => {
  const { teamId } = req.params;
  const { scope = "own" } = req.query;
  if (!TEAMS.includes(teamId)) return res.status(400).json({ error:"UNKNOWN_TEAM" });

  if (scope === "own") {
    return res.json(ROSTER[teamId].filter(p => p.active));
  } else if (scope === "neighbors") {
    const allowed = new Set((NEIGHBORS[teamId] || []));
    return res.json(ALL_PLAYERS.filter(p => p.active && allowed.has(p.team)));
  } else {
    return res.status(400).json({ error:"BAD_SCOPE" });
  }
});

app.post("/api/reload", (req, res) => {
  try { loadCsvData(); res.json({ ok:true, teams: TEAMS.length }); }
  catch (e) { res.status(500).json({ ok:false, error: e.message }); }
});

app.post("/api/submit", (req, res) => {
  try {
    const {
      assigned_team, date, submitted_by,
      participants = [], absences = [], guests = [],
      session_start, segments = [], session_end,
      comments
    } = req.body || {};

    if (!TEAMS.includes(assigned_team)) throw new Error("UNKNOWN_TEAM");
    if (!date) throw new Error("MISSING_DATE");
    if (!submitted_by) throw new Error("MISSING_SUBMITTER");
    if (!session_start) throw new Error("MISSING_SESSION_START");
    if (!session_end) throw new Error("MISSING_SESSION_END");

    const toMin = t => { const [hh, mm] = String(t).split(":").map(Number); return hh*60+mm; };
    const sStart = toMin(session_start);
    const sEnd = toMin(session_end);
    if (!(sStart < sEnd)) throw new Error("BAD_SESSION_RANGE");

    const ownActive = new Set(ROSTER[assigned_team].filter(p => p.active).map(p => p.player_id));
    const neighborTeams = new Set((NEIGHBORS[assigned_team] || []));
    const byId = BY_ID;

    for (const pid of participants) if (!ownActive.has(pid)) throw new Error("PARTICIPANT_NOT_IN_TEAM");

    for (const { player_id, reason } of absences) {
      if (!ownActive.has(player_id)) throw new Error("ABSENT_NOT_IN_TEAM");
      const okReasons = new Set(["sygdom","skade","skole","ferie","andet"]);
      if (!okReasons.has(reason)) throw new Error("BAD_ABSENCE_REASON");
    }

    for (const gid of guests) {
      const gp = byId[gid];
      if (!gp) throw new Error("UNKNOWN_GUEST");
      if (!gp.active) throw new Error("GUEST_INACTIVE");
      if (!neighborTeams.has(gp.team)) throw new Error("GUEST_NOT_ALLOWED_FROM_TEAM");
    }

    for (const seg of segments) {
      if (!seg.seg_start || !seg.seg_end || !seg.seg_desc) throw new Error("SEGMENT_INCOMPLETE");
      const a = toMin(seg.seg_start), b = toMin(seg.seg_end);
      if (!(sStart <= a && a < b && b <= sEnd)) throw new Error("SEGMENT_OUTSIDE_SESSION");
    }

    const ts = new Date().toISOString();

    ensureHeaderIfNeeded(assigned_team, ["session_start","session_end"]);
    appendRow(assigned_team, [ts, assigned_team, "META", date, submitted_by], [session_start, session_end]);

    for (const id of participants) {
      const p = byId[id];
      appendRow(assigned_team, [ts, assigned_team, "PARTICIPANT", date, submitted_by], [p.player_id, p.name]);
    }

    for (const { player_id, reason } of absences) {
      const p = byId[player_id];
      appendRow(assigned_team, [ts, assigned_team, "ABSENCE", date, submitted_by], [p.player_id, p.name, reason]);
    }

    for (const id of guests) {
      const p = byId[id];
      appendRow(assigned_team, [ts, assigned_team, "GUEST", date, submitted_by], [p.player_id, p.name, p.team]);
    }

    for (const seg of segments) {
      appendRow(assigned_team, [ts, assigned_team, "SEGMENT", date, submitted_by], [seg.seg_start, seg.seg_end, seg.seg_desc]);
    }

    if (comments && comments.trim() !== "") {
      appendRow(assigned_team, [ts, assigned_team, "COMMENT", date, submitted_by], [comments.trim()]);
    }

    res.json({ ok:true });
  } catch (err) {
    res.status(400).json({ ok:false, error: err.message });
  }
});

function getLocalIp(){
  const ifaces = os.networkInterfaces();
  for (const name of Object.keys(ifaces)) {
    for (const iface of ifaces[name] || []) {
      if (iface.family === "IPv4" && !iface.internal) return iface.address;
    }
  }
  return "localhost";
}

const PORT = process.env.PORT || 3000;
const HOST = "0.0.0.0";
app.listen(PORT, HOST, () => {
  const ip = getLocalIp();
  console.log(`Klar på http://localhost:${PORT}  •  På netværk:  http://${ip}:${PORT}`);
});
